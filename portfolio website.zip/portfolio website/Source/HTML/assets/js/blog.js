document.querySelectorAll(".blog-card").forEach((card) => {
  const title = card.querySelector(".blog-title");
  const closeBtn = card.querySelector(".close-btn");

  // Show details
  title.addEventListener("click", (e) => {
    e.stopPropagation();
    card.classList.add("active");
  });

  // Hide details
  closeBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    card.classList.remove("active");
  });
});
